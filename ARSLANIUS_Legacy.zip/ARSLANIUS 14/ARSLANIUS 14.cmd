@echo off
echo Starting ARSLANIUS
title ARSLANIUS 14
color 9b
pause
cls

:x

set /p y=
if %y%==Shutdown (echo Shutdown?
pause
exit)

set /p xx=
if %xx%==CreatedFolder (md NewFolder
echo Folder created)

set /p xxx=
if %xxx%==Admin (echo you are now an administrator)

set /p yy=
if %yy%==Notepad (start notepad.exe)

set /p z=
if %z%==MicrosoftEdge (start msedge.exe)

set /p p=
if %p%==Explorer (start Explorer++.exe)

set /p q=
if %q%==Help (echo Explorer-MicrosoftEdge-Calc-Notepad-MiniDOS-Admin-CreatedFolder-Paint-Shutdown-Help-color2f-color3f-color4f-color9b-Reboot-Miner.game)

set /p g=
if %g%==Paint (start mspaint.exe)

set /p xxxx=
if %xxxx%==Bsod (CLS
echo :(
echo There is a problem on your device, we do not collect additional information, please contact the administrators or owner
color 3f
echo ReBooting...
pause
color 9b
cls)

set /p f=
if %f%==Calc (start Calc.bat)

set /p j=
if %j%==color2f (color 2f)

set /p g=
if %g%==color3f (color 3f)

set /p hi=
if %hi%==color4f (color 4f)

set /p jik=
if %jik%==color9b (color 9b)

set /p bye=
if %bye%==Reboot (color 0f
CLS
CLS
pause
Color 9b)

set /p ret=
if %ret%==MiniDOS (start C:\ARSLANIUS\"ARSLANIUS 14"\"Setting And System Files"\MiniDOS.SYSTEM.Files\RS-DOS.bat)

set /p la=
if %la%==Miner.game (start C:\ARSLANIUS\"ARSLANIUS 14"\Programs\miner.cmd)
goto x