@echo off
echo Welcome to in ARSLANIUS 2.0!
title RS - DOS...ARSLANIUS 2.0
color 6f

:x
set "cmd="
set /p "cmd="

if "%cmd%"=="Youtube" (echo 88gh)
if "%cmd%"=="Exit" (echo Exit? & pause & exit)
if "%cmd%"=="CreatedFolder" (md MyFolder & echo Folder created & goto x)
if "%cmd%"=="Admin" (echo you are now an administrator & goto x)
if "%cmd%"=="Notepad" (start notepad.exe & goto x)

echo "%cmd%" is not recognized.
goto x