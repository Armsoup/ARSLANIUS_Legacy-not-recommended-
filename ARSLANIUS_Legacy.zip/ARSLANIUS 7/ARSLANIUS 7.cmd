@echo off
echo Welcome to in ARSLANIUS 7!
title ARSLANIUS 7
color 3f

:x
set "cmd="
set /p "cmd="

if /i "%cmd%"=="" goto x
if /i "%cmd%"=="Youtube" (echo 88gh
goto x)
if /i "%cmd%"=="Shutdown" (echo Shutdown?
pause
exit)
if /i "%cmd%"=="CreatedFolder" (md MyFolder
echo Folder created
goto x)
if /i "%cmd%"=="Admin" (echo you are now an administrator
goto x)
if /i "%cmd%"=="Notepad" (start notepad.exe
goto x)
if /i "%cmd%"=="Iexplore" (start iexplore.exe
goto x)
if "%cmd%"=="Explorer" (start Explorer++.exe
goto x)
if /i "%cmd%"=="Help" (echo Explorer-Youtube-Iexplore-Calc-Notepad-Admin-CreatedFolder-Paint-Shutdown-Help-color2f-color3f-color4f-Reboot
goto x)
if /i "%cmd%"=="Paint" (start mspaint.exe
goto x)
if /i "%cmd%"=="Bsod" (CLS
echo :( BSOD BSOD BSOD
echo There is a problem on your device, we do not collect additional information, please contact the administrators or owner
color 1f
pause
exit)
if /i "%cmd%"=="Calc" (start Calc.bat
goto x)
if /i "%cmd%"=="color2f" (color 2f
goto x)
if /i "%cmd%"=="color3f" (color 3f
goto x)
if /i "%cmd%"=="color4f" (color 4f
goto x)
if /i "%cmd%"=="Reboot" (color 0f
CLS
CLS
pause
Color 3f
CLS
echo Welcome to in ARSLANIUS 7!
goto x)

echo "%cmd%" is not recognized.
goto x