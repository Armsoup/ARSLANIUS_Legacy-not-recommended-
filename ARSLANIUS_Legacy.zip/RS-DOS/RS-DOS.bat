@echo off
title RS - DOS
echo Welcome

:x
set "input="
set /p "input="

if /i "%input%"=="youtube" echo 88gh && goto x
if /i "%input%"=="exit" echo exit? && pause && exit
if /i "%input%"=="F+C" md NewFolder && echo Folder created && goto x
if /i "%input%"=="Admin" echo you are now an administrator && goto x

if not defined input goto x
echo %input% | findstr /i "youtube exit F+C Admin" >nul
if errorlevel 1 echo Unknown command: %input% && goto x

goto x