@echo off
title ARSLANIUS 95
color 2f
echo Welcome to ARSLANIUS 95!

:x
set "input="
set /p "input="

if /i "%input%"=="Youtube" echo 88gh && goto x
if /i "%input%"=="Exit" echo Exit? && pause && exit
if /i "%input%"=="CreatedFolder" md MyFolder && echo Folder created && goto x
if /i "%input%"=="Admin" echo you are now an administrator && goto x
if /i "%input%"=="Notepad" start notepad.exe && goto x
if /i "%input%"=="Iexplore" start iexplore.exe && goto x
if /i "%input%"=="Explorer" start Explorer++.exe && goto x
if /i "%input%"=="Help" echo Explorer-Youtube-Iexplore-Calc-Notepad-Admin-CreatedFolder-Paint-Exit-Help && goto x
if /i "%input%"=="Paint" start mspaint.exe && goto x
if /i "%input%"=="Bsod" cls && echo :( BSOD BSOD BSOD && echo We don't know why the BSOD appeared on your device, and yes, there is a problem on your device, we don't collect additional information, contact the publisher && color 1f && pause && exit
if /i "%input%"=="Calc" start Calc.bat && goto x

if not defined input goto x
echo %input% | findstr /i "Youtube Exit CreatedFolder Admin Notepad Iexplore Explorer Help Paint Bsod Calc" >nul
if errorlevel 1 echo Unknown command: %input% && goto x

goto x