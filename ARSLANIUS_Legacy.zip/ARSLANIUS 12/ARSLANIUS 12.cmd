@echo off
title ARSLANIUS 12
color 8b
echo Starting ARSLANIUS
pause
cls

:x
set "input="
set /p "input="

if /i "%input%"=="Youtube" echo 88gh && goto x
if /i "%input%"=="Shutdown" echo Shutdown? && pause && exit
if /i "%input%"=="CreatedFolder" md NewFolder && echo Folder created && goto x
if /i "%input%"=="Admin" echo you are now an administrator && goto x
if /i "%input%"=="Notepad" start notepad.exe && goto x
if /i "%input%"=="MicrosoftEdge" start msedge.exe && goto x
if /i "%input%"=="Explorer" start Explorer++.exe && goto x
if /i "%input%"=="Help" echo Explorer-Youtube-MicrosoftEdge-Calc-Notepad-Admin-CreatedFolder-Paint-Shutdown-Help-color2f-color3f-color4f-color8b-Reboot && goto x
if /i "%input%"=="Paint" start mspaint.exe && goto x
if /i "%input%"=="Bsod" cls && echo :( && echo There is a problem on your device, we do not collect additional information, please contact the administrators or owner && color 3f && echo ReBooting... && pause && color 8b && cls && goto x
if /i "%input%"=="Calc" start Calc.bat && goto x
if /i "%input%"=="color2f" color 2f && goto x
if /i "%input%"=="color3f" color 3f && goto x
if /i "%input%"=="color4f" color 4f && goto x
if /i "%input%"=="c" color 8b && goto x
if /i "%input%"=="Reboot" color 0f && cls && cls && pause && color 8b && goto x

if not defined input goto x
echo %input% | findstr /i "Youtube Shutdown CreatedFolder Admin Notepad MicrosoftEdge Explorer Help Paint Bsod Calc color2f color3f color4f c Reboot" >nul
if errorlevel 1 echo Unknown command: %input% && goto x

goto x