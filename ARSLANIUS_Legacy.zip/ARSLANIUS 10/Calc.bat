@echo off
title Calculator
color 2f
:start
set /p sum=Please enter the question:
set /a ans=%sum%
echo The Answer=%ans%
pause
cls
echo Previos Answer=%ans%
cls
goto start