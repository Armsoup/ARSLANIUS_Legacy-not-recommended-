@echo off
echo Welcome to in ARSLANIUS 3.0!
title RS - DOS...ARSLANIUS 3.0
color 6f

:x
set "cmd="
set /p "cmd="

if "%cmd%"=="Youtube" (echo 88gh
goto x)
if "%cmd%"=="Exit" (echo Exit?
pause
exit
goto x)
if "%cmd%"=="CreatedFolder" (md MyFolder
echo Folder created
goto x)
if "%cmd%"=="Admin" (echo you are now an administrator
goto x)
if "%cmd%"=="Notepad" (start notepad.exe
goto x)
if "%cmd%"=="Explorer" (start Explorer++.exe 
goto x)
if "%cmd%"=="Help" (echo Explorer-Youtube-Notepad-Admin-CreatedFolder-Exit-Help 
goto x)

echo "%cmd%" is not recognized.
goto x