@echo off
title BarOS 3.0
color 2f
echo Welcome to BarOS 3.0!

:x
set "input="
set /p "input="

if /i "%input%"=="Youtube" echo 88gh && goto x
if /i "%input%"=="Shutdown" echo Shutdown? && pause && exit
if /i "%input%"=="CreatedFolder" md MyFolder && echo Folder created && goto x
if /i "%input%"=="Notepad" start notepad.exe && goto x
if /i "%input%"=="Iexplore" start iexplore.exe && goto x
if /i "%input%"=="Explorer" start Explorer++.exe && goto x
if /i "%input%"=="Help" echo Explorer-Youtube-Iexplore-Calc-Notepad-CreatedFolder-Paint-Shutdown-Help && goto x
if /i "%input%"=="Paint" start mspaint.exe && goto x
if /i "%input%"=="Bsod" cls && echo :( BSOD BSOD BSOD && echo На вашем устройстве возникла проблема, мы не собираем дополнительную информацию,свяжитесь с Администраторами или Владельцем && color 1f && pause && exit
if /i "%input%"=="Calc" start Calc.bat && goto x

if not defined input goto x
echo %input% | findstr /i "Youtube Shutdown CreatedFolder Notepad Iexplore Explorer Help Paint Bsod Calc" >nul
if errorlevel 1 echo Unknown command: %input% && goto x

goto x