@echo off
echo Welcome
title RS - DOS in Emulator ARSLANIUS 15

:x

set /p x=
if %x%==ARS (start C:\ARSLANIUS\"ARSLANIUS 15"\"ARSLANIUS 15".cmd)

set /p y=
if %y%==exit (echo exit?
pause
exit)

set /p xx=
if %xx%==F+C (md NewFolder
echo Folder created)

set /p xxx=
if %xxx%==Admin (echo you are now an administrator)
goto x