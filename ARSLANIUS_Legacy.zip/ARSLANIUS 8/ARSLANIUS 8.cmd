@echo off
echo Welcome to in ARSLANIUS 8!
title ARSLANIUS 8
color 3f

:x
set "cmd="
set /p "cmd="

if "%cmd%"=="Youtube" (echo 88gh
goto x)
if "%cmd%"=="CreatedFolder" (md MyFolder
echo Folder created
goto x)
if "%cmd%"=="Admin" (echo you are now an administrator
goto x)
if "%cmd%"=="Notepad" (start notepad.exe
goto x)
if "%cmd%"=="Iexplore" (start iexplore.exe
goto x)
if "%cmd%"=="Explorer" (start Explorer++.exe
goto x)
if "%cmd%"=="Help" (echo Explorer-Youtube-Iexplore-Calc-Notepad-Admin-CreatedFolder-Paint-Help-color2f-color3f-color4f-Reboot
goto x)
if "%cmd%"=="Paint" (start mspaint.exe
goto x)
if "%cmd%"=="Bsod" (CLS
echo :(
echo There is a problem on your device, we do not collect additional information, please contact the administrators or owner
color 3f
echo ReBooting...
pause
color 3f
cls
goto x)
if "%cmd%"=="Calc" (start Calc.bat
goto x)
if "%cmd%"=="color2f" (color 2f
goto x)
if "%cmd%"=="color3f" (color 3f
goto x)
if "%cmd%"=="color4f" (color 4f
goto x)
if "%cmd%"=="Reboot" (color 1f
CLS
CLS
pause
Color 3f
goto x)

echo "%cmd%" is not recognized.
goto x