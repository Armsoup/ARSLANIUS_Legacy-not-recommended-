@echo off
chcp 1251
shutdown -s -f -t 1