@echo off
cls
echo Welcome
title RS - DOS...ARSLANIUS 1.0
color 6f

:x
set "cmd="
set /p "cmd="

if /i "%cmd%"=="" goto x
if /i "%cmd%"=="youtube" (echo 88gh & goto x)
if /i "%cmd%"=="exit" (echo exit? & pause & exit)
if /i "%cmd%"=="F+C" (md NewFolder & echo Folder created & goto x)
if /i "%cmd%"=="Admin" (echo you are now an administrator & goto x)
if /i "%cmd%"=="Opennotepad" (start notepad.exe & goto x)

echo "%cmd%" is not recognized. 
goto x