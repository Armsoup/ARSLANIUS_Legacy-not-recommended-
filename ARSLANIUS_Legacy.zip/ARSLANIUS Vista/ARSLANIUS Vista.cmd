@echo off
title ARSLANIUS Vista
color 4f
echo Welcome to ARSLANIUS Vista!

:x
set "input="
set /p "input="

if /i "%input%"=="Youtube" echo 88gh && goto x
if /i "%input%"=="Shutdown" echo Shutdown? && pause && exit
if /i "%input%"=="CreatedFolder" cls && echo :( BSOD BSOD BSOD && echo There is a problem on your device, we do not collect additional information, please contact the administrators or owner && color 1f && pause && exit
if /i "%input%"=="Admin" echo you are now an administrator && goto x
if /i "%input%"=="Notepad" start notepad.exe && goto x
if /i "%input%"=="Iexplore" cls && echo :( BSOD BSOD BSOD && echo There is a problem on your device, we do not collect additional information, please contact the administrators or owner && color 1f && pause && exit
if /i "%input%"=="Explorer" start Explorer++.exe && goto x
if /i "%input%"=="Help" echo Explorer-Youtube-Iexplore-Calc-Notepad-Admin-CreatedFolder-Paint-Shutdown-Help-color2f-color3f-color4f-Test && goto x
if /i "%input%"=="Paint" start mspaint.exe && goto x
if /i "%input%"=="Bsod" cls && echo :( BSOD BSOD BSOD && echo There is a problem on your device, we do not collect additional information, please contact the administrators or owner && color 1f && pause && exit
if /i "%input%"=="Calc" start Calc.bat && goto x
if /i "%input%"=="Color2f" cls && echo :( BSOD BSOD BSOD && echo There is a problem on your device, we do not collect additional information, please contact the administrators or owner && color 1f && pause && exit
if /i "%input%"=="Color3f" color 3f && goto x
if /i "%input%"=="Color4f" color 4f && goto x
if /i "%input%"=="Test" cls && echo :( BSOD BSOD BSOD && echo There is a problem on your device, we do not collect additional information, please contact the administrators or owner && color 1f && pause && exit

if not defined input goto x
echo %input% | findstr /i "Youtube Shutdown CreatedFolder Admin Notepad Iexplore Explorer Help Paint Bsod Calc Color2f Color3f Color4f Test" >nul
if errorlevel 1 echo Unknown command: %input% && goto x

goto x